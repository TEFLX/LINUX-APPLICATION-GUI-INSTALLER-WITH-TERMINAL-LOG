
from PyQt5 import QtCore, QtGui, QtWidgets
import sys,os
from PyQt5.QtGui import QPixmap,QIcon
from PyQt5.QtWidgets import QApplication,QLabel, QHBoxLayout, QMainWindow, QWidget
from PyQt5.QtGui import QPixmap,QImage
from PyQt5.QtCore import Qt

class SecondWindow(QtWidgets.QMainWindow):

    def __init__(self, parent=None, label_text="" , label_disc="", label_image=""):
        super(SecondWindow, self).__init__(parent)
        self.setupUi(self)
        self.label_2.setText(label_text )
        self.label_3.setText(label_disc )
        original_pixmap = QPixmap(label_image)
        desired_width = 100
        desired_height = 100
        scaled_pixmap = original_pixmap.scaled(desired_width, desired_height, QtCore.Qt.KeepAspectRatio)
        self.label_4.setPixmap(scaled_pixmap)
        

    def setupUi(self, MainWindow):

        MainWindow.setObjectName("MainWindow")
        MainWindow.setGeometry(0, 0, 1050, 701) 
        # MainWindow.resize(1100, 701)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame_5 = QtWidgets.QFrame(self.centralwidget)
        self.frame_5.setGeometry(QtCore.QRect(0, 0, 1101, 671))
        self.frame_5.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_5.setObjectName("frame_5")
        self.frame_2 = QtWidgets.QFrame(self.frame_5)
        self.frame_2.setGeometry(QtCore.QRect(50, 80, 911, 551))
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.frame_4 = QtWidgets.QFrame(self.frame_2)
        self.frame_4.setGeometry(QtCore.QRect(50, 20, 781, 201))
        self.frame_4.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_4.setObjectName("frame_4")
        self.label_4 = QtWidgets.QLabel(self.frame_4)
        self.label_4.setGeometry(QtCore.QRect(50, 20, 141, 141))
        self.label_4.setObjectName("label_4")
        self.label_2 = QtWidgets.QLabel(self.frame_4)
        self.label_2.setGeometry(QtCore.QRect(200, 20, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(22)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.frame_4)
        self.label_3.setGeometry(QtCore.QRect(200, 70, 500, 31))
        self.label_3.setObjectName("label_3")
        self.label_3.setWordWrap(True)
        self.pushButton = QtWidgets.QPushButton(self.frame_4)
        self.pushButton.setGeometry(QtCore.QRect(200, 110, 101, 60))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.frame_4)
        self.pushButton_2.setGeometry(QtCore.QRect(310, 110, 101, 60))
        self.pushButton_2.setObjectName("pushButton_2")
        self.radioButton = QtWidgets.QRadioButton(self.frame_4)
        self.radioButton.setGeometry(QtCore.QRect(670, 10, 95, 20))
        self.radioButton.setObjectName("radioButton")
        self.radioButton_2 = QtWidgets.QRadioButton(self.frame_4)
        self.radioButton_2.setGeometry(QtCore.QRect(670, 30, 95, 20))
        self.radioButton_2.setObjectName("radioButton_2")
        self.frame_3 = QtWidgets.QFrame(self.frame_2)
        self.frame_3.setGeometry(QtCore.QRect(240, 230, 511, 281))
        self.frame_3.setStyleSheet("border-image: url(:/newPrefix/Screenshot 2024-02-16 175045.png);")
        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.frame_3.setStyleSheet("border: none;")

        self.frame = QtWidgets.QFrame(self.frame_5)
        self.frame.setGeometry(QtCore.QRect(-10, 0, 1131, 81))
        self.frame.setStyleSheet("background-color: rgb(0, 0, 0);")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")

        
#         self.label = QtWidgets.QLabel(self.frame)
#         self.label.setGeometry(QtCore.QRect(870, -20, 261, 141))
#         font = QtGui.QFont()
#         font.setPointSize(16)
#         self.label.setFont(font)
#         self.label.setStyleSheet("border-image: url(:/newPrefix/loho-removebg-preview.png);\n"
# "")
#         self.label.setText("")
#         self.label.setObjectName("label")
        # self.pushButton_3 = QtWidgets.QPushButton(self.frame)
        # self.pushButton_3.setGeometry(QtCore.QRect(20, 0, 61, 81))
        # self.pushButton_3.setStyleSheet("image: url(:WhatsApp_Image_2024-02-16_at_17.42.16_5552f279-removebg-preview.png);")
        # self.pushButton_3.setText("")
        
        # self.pushButton_3.setObjectName("pushButton_3")
        
        current_dir = os.path.dirname(os.path.abspath(__file__))

        left_logo_path = os.path.join(current_dir, 'WhatsApp_Image_2024-02-16_at_17.42.16_5552f279-removebg-preview.png')
        left_logo_pixmap = QPixmap(left_logo_path)
        left_logo_pixmap = left_logo_pixmap.scaled(50, 50, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
        left_logo_label = QLabel()
        left_logo_label.setPixmap(left_logo_pixmap)

        right_logo_path = os.path.join(current_dir, 'loho-removebg-preview.png')
        # right_logo_pixmap = QPixmap(right_logo_path)
        with open(right_logo_path, "rb") as f:
            right_logo_data = f.read()

        right_logo_pixmap = QPixmap.fromImage(QImage.fromData(right_logo_data))
        right_logo_pixmap = right_logo_pixmap.scaled(261, 141, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        right_logo_label = QLabel()
        right_logo_label.setPixmap(right_logo_pixmap)

        # Create a layout for the frame
        layout = QHBoxLayout(self.frame)

        layout.addSpacing(5)  # Add spacing to the left
        layout.addWidget(left_logo_label, 0, QtCore.Qt.AlignLeft| Qt.AlignVCenter)
        layout.addStretch(1)  # Add a stretch to push the right logo to the right
        layout.addWidget(right_logo_label, 0, Qt.AlignRight | Qt.AlignVCenter)
        layout.addSpacing(5)
        layout.setContentsMargins(5, 5, 5, 5)  # Add some spacing around the logo

        MainWindow.setCentralWidget(self.centralwidget)

        

        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1103, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "Launch"))
        self.pushButton_2.setText(_translate("MainWindow", "Remove"))
        self.radioButton.setText(_translate("MainWindow", "florida"))
        self.radioButton_2.setText(_translate("MainWindow", "debian"))


