
from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from PyQt5.QtGui import QPixmap,QIcon
from PyQt5.QtCore import QSize
from PyQt5.QtWidgets import QPushButton, QLabel
class SecondWindow(QtWidgets.QMainWindow):

    def __init__(self, parent=None, label_text="" , label_disc="", label_image=""):
        super(SecondWindow, self).__init__(parent)
        self.setupUi(self)
        self.label_2.setText(label_text )
        self.label_3.setText(label_disc )
        self.label_3.setWordWrap(True)


        original_pixmap = QPixmap(label_image)
        desired_width = 100
        desired_height = 100
        scaled_pixmap = original_pixmap.scaled(desired_width, desired_height, QtCore.Qt.KeepAspectRatio)
        self.label_4.setPixmap(scaled_pixmap)

    def setupUi(self, MainWindow):

        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1115, 701)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame_5 = QtWidgets.QFrame(self.centralwidget)
        self.frame_5.setGeometry(QtCore.QRect(0, 0, 1150, 671))
        self.frame_5.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_5.setObjectName("frame_5")
        self.frame_5.setStyleSheet("border: none;")

        self.frame_2 = QtWidgets.QFrame(self.frame_5)
        self.frame_2.setGeometry(QtCore.QRect(50, 80, 1150, 551))
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.frame_4 = QtWidgets.QFrame(self.frame_2)
        self.frame_4.setGeometry(QtCore.QRect(50, 50, 900, 201))
        self.frame_4.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_4.setObjectName("frame_4")

        self.label_4 = QtWidgets.QLabel(self.frame_4)
        self.label_4.setGeometry(QtCore.QRect(50, 10, 141, 141))
        self.label_4.setObjectName("label_4")
        self.label_2 = QtWidgets.QLabel(self.frame_4)
        self.label_2.setGeometry(QtCore.QRect(200, 30, 250, 41))
        font = QtGui.QFont()
        font.setPointSize(22)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.frame_4)
        self.label_3.setGeometry(QtCore.QRect(200, 80, 500, 31))
        self.label_3.setObjectName("label_3")
        self.pushButton = QtWidgets.QPushButton(self.frame_4)
        self.pushButton.setGeometry(QtCore.QRect(200, 140, 101, 41))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.setStyleSheet("border: 1px solid #999999;")  # Add border style with very light shade of black

        self.pushButton_2 = QtWidgets.QPushButton(self.frame_4)
        self.pushButton_2.setGeometry(QtCore.QRect(330, 140, 101, 41))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.setStyleSheet("border: 1px solid #999999;")

        self.radioButton = QtWidgets.QRadioButton(self.frame_4)
        self.radioButton.setGeometry(QtCore.QRect(775, 30, 95, 20))
        self.radioButton.setObjectName("radioButton")
        self.radioButton_2 = QtWidgets.QRadioButton(self.frame_4)
        self.radioButton_2.setGeometry(QtCore.QRect(775, 55, 95, 20))
        self.radioButton_2.setObjectName("radioButton_2")
        self.frame_3 = QtWidgets.QFrame(self.frame_2)
        self.frame_3.setGeometry(QtCore.QRect(235, 270, 530, 281))

        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.frame_3.setStyleSheet("border: none;")
        self.frame_3.setStyleSheet("border: 1px solid #999999;")  # Add border style with very light shade of black


        self.frame = QtWidgets.QFrame(self.frame_5)
        self.frame.setGeometry(QtCore.QRect(0, 0, 1150, 81))
        self.frame.setStyleSheet("background-color: rgb(0, 0, 0);")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(848, -20, 261, 141))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label.setFont(font)
        image_path = 'loho-removebg-preview.png'
        pixmap = QPixmap(image_path)
        self.label.setPixmap(pixmap)
        self.label.setScaledContents(True)
        self.label.setObjectName("label")

        self.pushButton_3 = QPushButton(self.frame)
        self.pushButton_3.setGeometry(QtCore.QRect(30, 0, 61, 81))
        self.pushButton_3.setText("")
        self.pushButton_3.setObjectName("pushButton_3")
        image_path = "img.png"
        pixmap = QPixmap(image_path)
        pixmap_resized = pixmap.scaled(QSize(60, 60))
        self.pushButton_3.setIcon(QIcon(pixmap_resized))
        self.pushButton_3.setIconSize(pixmap_resized.size())
        MainWindow.setCentralWidget(self.centralwidget)

        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1103, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "Launch"))
        self.pushButton_2.setText(_translate("MainWindow", "Remove"))
        self.radioButton.setText(_translate("MainWindow", "florida"))
        self.radioButton_2.setText(_translate("MainWindow", "debian"))


